import img from "../assets/react.js.png";
import img2 from "../assets/Nasi.jpeg";
import img3 from "../assets/Murid.jpeg";
import img4 from "../assets/Sate.jpeg";
import img5 from "../assets/Uang.jpg";
export const posts = [
  {
    id: 1,
    title: "How to use React",
    excerpt: "Learn the basics of React in this introductory post.",
    content: "This is the full content of the React blog post.",
    date: "2025-05-15",
    imageUrl: img,
    category: "React",
  },
  {
    id: 2,
    title: "Tailwind Tips & Tricks",
    excerpt: "Make your styling faster and cleaner using Tailwind.",
    content: "This post will show you cool Tailwind techniques.",
    date: "2025-05-14",
    imageUrl: img,
    category: "Tailwind",
  },
  {
    id: 3,
    title: "Makan Sate Padang",
    excerpt: "Tutorial Makan Sate Biar Ga Salah.",
    content: "Video Orang Makan Sate.",
    date: "2025-05-14",
    imageUrl: img4,
    category: "Sate",
  },
  {
    id: 4,
    title: "Cara Mengubah Saldo Dana Jadi Pahala",
    excerpt: "Tutor Memperbanyak Pahala.",
    content: "Video Orang Dapat pahala.",
    date: "2025-05-14",
    imageUrl: img5,
    category: "Uang",
  },
  {
    id: 5,
    title: "Cara Mengubah Ketua Kelas Menjadi Beban Kelas",
    excerpt: "Kerjaan Ketua Kelas.",
    content: "Teknik Menambah beban keluarga.",
    date: "2025-05-14",
    imageUrl: img3,
    category: "Manusia",
  },
  {
    id: 6,
    title: "Cara Makan Nasi Biar ga berantakan",
    excerpt: "Orang makan nasi.",
    content: "Tutor makan nasi.",
    date: "2025-05-14",
    imageUrl: img2,
    category: "Nasi",
  },
];
