import React , {useState, useEffect} from 'react';
import { posts } from "../data/posts";
import { useParams } from "react-router-dom";

const NewsDetail = () => {
 const { id } = useParams();
 const post = posts.find((p)=> p.id == parseInt(id));
 const [theme, setTheme] = useState("light");
 const themeHandle = () => {
    if (theme == "light") {
        setTheme("dark");
    } else {
        setTheme("light");
    }
 };
useEffect(() => {
    if (theme == "dark"){
        document.querySelector("html")?.classList.add("dark");
    } else {
        document.querySelector("html")?.classList.remove("dark");
    }
}, [theme])
    return (
    <div className='bg-white dark:bg-gray-800 w-full h-screen mx-auto p-4'>
        <button onClick={themeHandle} className='bg-gray-800 text-white dark:bg-white dark:text-gray-800 px-4 py-2'>{theme}</button>
        <img src={post.imageUrl} alt={post.title} className="w-full h-auto object-hover"/>
        <h1 className='text-xl text-gray-800 dark:text-white'>{post.title}</h1>
        <p className='text-md text-gray-800 dark:text-gray-'>{post.content}</p>
    </div>
    );
};

export default NewsDetail