import React, { useState, useEffect } from 'react';
import Card from '../components/Card';
import { posts } from '../data/posts';

const Home = () => {
  const [search, setSearch] = useState("")
  const [category, setCategory] = useState("all");
  const categories = ["all",  ...new Set(posts.map((post) => post.category))];

  const filterdPosts = posts.filter((post) => {
    const matchTitle = post.title.
    toLowerCase().
    includes(search.
    toLowerCase())
    const matchCategory = category == "all" ? true : post.category == category;
    return matchTitle && matchCategory;
  });

  const handleCategory = (e) => {
    setCategory(e.target.value);
  };

  const handleChange = (e) => {
    setSearch(e.target.value);
    console.log('data search', search);
  };
  return (
    <div className='max-w-6xl mx-auto p-6'>
      <div>
        <h1 className='text-3xl font-bold text-center mb-8'>My Kisah</h1>
        <input
          type="text"
          placeholder='Search by Title'
          value={search}
          onChange={handleChange}
          className='w-full max-w-md px-4 py-2 border border-gray-400'
        />
        <select 
        value={category} 
        type="text" 
        placeholder="search by category" 
        onChange={handleCategory}
        >
          {categories.map ((category,index)=>{
            return (
            <option key={index} value={category}>
              {category}
            </option>
            );
          })};
        </select>
      </div>
      {/* menampilkan post */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {
          filterdPosts.length > 0 ? (
            filterdPosts.map((post) => <Card key={post.id} post={post} />)
          ) : (
            <p className="col-span-full text-center">Not Posts Found</p>
          )}
      </div>
    </div>
  );
};

//(e) => setSearch(e.target.value)
export default Home